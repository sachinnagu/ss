<?php
$con=mysqli_connect("localhost","root","","nanu");
if(mysqli_connect_errno())
{
echo "nanu".mysqli_connect_error();
}
?>